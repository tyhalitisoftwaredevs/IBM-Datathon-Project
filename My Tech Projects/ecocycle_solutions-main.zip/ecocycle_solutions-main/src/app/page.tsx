// src/app/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Navbar with always-visible hamburger */}
      <header className="bg-gradient-to-r from-green-50 to-emerald-100 py-4 px-4 sm:px-6 lg:px-8 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          {/* Always-visible Hamburger + Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link
                  href="/"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50 hover:text-emerald-700"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link
                  href="/about"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50 hover:text-emerald-700"
                  onClick={() => setIsMenuOpen(false)}
                >
                  About Us
                </Link>
              </div>
            )}
          </div>

          {/* Brand Name (Visible on desktop for balance) */}
          <div className="hidden md:block font-bold text-xl text-gray-900">
            EcoCycle Solutions
          </div>

          {/* Login Button - Highlighted */}
          <div>
            <Link
              href="/login"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
            >
              Login
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-50 to-emerald-100 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Turn Waste into Work
          </h1>
          <p className="text-lg md:text-xl text-gray-700 mb-8">
            EcoCycle Solutions empowers unemployed South African youth by connecting them with recycling opportunities through a smart, data-driven platform.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              href="/signup"
              className="rounded-full bg-emerald-600 text-white px-6 py-3 font-medium hover:bg-emerald-700 transition-colors"
            >
              Join Us
            </Link>
            <Link
              href="#features"
              className="rounded-full border border-emerald-600 text-emerald-600 px-6 py-3 font-medium hover:bg-emerald-50 transition-colors"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Problem & Mission */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">The Challenge</h2>
            <p className="text-gray-700 mb-4">
              Over 60% of South African youth are unemployed or not in education. Meanwhile, recyclable waste goes uncollected due to fragmented systems and lack of market access.
            </p>
          </div>
          <div>
            <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
            <p className="text-gray-700 mb-4">
              Build a digital ecosystem that turns recyclables into income, skills, and environmental impact—starting with youth at the center.
            </p>
          </div>
        </div>
      </section>

      {/* User Types */}
      <section className="py-16 bg-gray-50 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Who We Serve</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Unemployed Youth",
                desc: "Collect, sort, and sell recyclables. Earn cash, learn green skills, and access real-time market data.",
                icon: '🌱'
              },
              {
                title: "Recycling Agents",
                desc: "Post demand, schedule pickups, and discover high-yield collection zones using live analytics.",
                icon: '🚚'
              },
              {
                title: "Schools & Businesses",
                desc: "Track recycling impact, run challenges, and contribute to a cleaner, circular economy.",
                icon: '🏫'
              },
            ].map((user, idx) => (
              <div key={idx} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center">
                <div className="text-4xl mb-4">{user.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{user.title}</h3>
                <p className="text-gray-600">{user.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Core Features */}
      <section id="features" className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">Platform Features</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
         { title: "Data Dashboard", desc: "Live trends on in-demand materials and pricing." },
         { title: "User Profiles", desc: "Personalized dashboards for all user types." },
         { title: "Recycling Marketplace", desc: "Direct connection between collectors and buyers." },
         { title: "Recycling Guidance", desc: "Micro-courses on sorting and best practices." },
         { title: "Rewards System", desc: "Earn cash or vouchers for every kg recycled." },
         { title: "Impact Tracker", desc: "Measure CO₂ saved, jobs created, and tons recycled." },
       ].map((feature, idx) => (
         <div key={idx} className="bg-emerald-50 p-6 rounded-lg">
           {/* <div className="text-2xl mb-2">{feature.icon}</div> */}
              <h3 className="font-bold text-lg mb-1">{feature.title}</h3>
              <p className="text-gray-700">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-emerald-600 text-white text-center px-4 sm:px-6">
        <h2 className="text-3xl font-bold mb-4">Ready to Build the Future?</h2>
        <p className="max-w-2xl mx-auto mb-8">
          Join us in creating sustainable jobs and a cleaner South Africa—one recyclable at a time.
        </p>
        <Link
          href="/signup"
          className="inline-block bg-white text-emerald-600 font-medium px-6 py-3 rounded-full hover:bg-gray-100 transition-colors"
        >
          Get Started
        </Link>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-gray-600 text-sm">
        <div className="flex flex-wrap justify-center gap-6 mb-4">
          <Link href="/about" className="hover:underline">
            About
          </Link>
          <Link href="https://nextjs.org/learn" className="hover:underline" target="_blank" rel="noopener noreferrer">
            Learn
          </Link>
          <Link href="https://vercel.com/templates?framework=next.js" className="hover:underline" target="_blank" rel="noopener noreferrer">
            Examples
          </Link>
          <Link href="https://nextjs.org" className="hover:underline" target="_blank" rel="noopener noreferrer">
            Go to nextjs.org →
          </Link>
        </div>
        <p>© {new Date().getFullYear()} EcoCycle Solutions. For a greener, fairer economy.</p>
      </footer>
    </div>
  );
}