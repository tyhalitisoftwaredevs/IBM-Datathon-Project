// src/app/about/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function AboutPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="../" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="../about" className="block px-4 py-2 text-gray-800 font-medium bg-emerald-50 rounded" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="../login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Login
                </Link>
                <Link href="../signup" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Sign Up
                </Link>
              </div>
            )}
          </div>

          <div className="hidden md:block font-bold text-xl text-gray-900">
            EcoCycle Solutions
          </div>
          <div>
            <Link
              href="../login"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
            >
              Login
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold text-center mb-12">About EcoCycle Solutions</h1>

        <section className="mb-12">
          <p className="text-gray-700 text-lg leading-relaxed">
            EcoCycle Solutions is a smart, eco-driven recycling platform designed to make waste management simple, accessible, and impactful. Whether you're an individual, a household, a business, or a community organization, we help you take control of your recycling efforts and contribute to a cleaner, more sustainable future.
          </p>
          <p className="text-gray-700 mt-4">
            We believe that recycling should be easy, rewarding, and part of everyday life.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
          <p className="text-gray-700">
            Our mission is to empower unemployed youth in South Africa by building a data-driven recycling ecosystem that connects individuals, recycling agents, schools, and companies. Through this platform, we aim to turn recyclable waste into economic opportunity, while promoting environmental sustainability and skills development in the green economy.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4">Our Vision</h2>
          <p className="text-gray-700">
            A connected world where recycling is second nature, waste is minimized, and every user plays a part in protecting the planet.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">What We Offer</h2>
          <ul className="space-y-3 text-gray-700">
            <li className="flex items-start">
              <span><strong>On-Demand Collection</strong> – Schedule pickups at your convenience.</span>
            </li>
            <li className="flex items-start">
              <span><strong>Material Tracking</strong> – See how much you’ve recycled and its environmental impact.</span>
            </li>
            <li className="flex items-start">
              <span><strong>Business & Organization Solutions</strong> – Manage recycling at scale with reporting and scheduling tools.</span>
            </li>
            <li className="flex items-start">
              <span><strong>Eco-Rewards</strong> – Earn points or incentives for consistent recycling efforts.</span>
            </li>
            <li className="flex items-start">
              
              <span><strong>Location-Based Services</strong> – Connect with local recycling centres and verified agents.</span>
            </li>
          </ul>
        </section>

        <section className="mb-12 bg-emerald-50 p-6 rounded-xl">
          <h2 className="text-2xl font-bold mb-3">Why Choose EcoCycle Solutions?</h2>
          <p className="text-gray-700">
            We're not just another recycling app — we’re a movement toward smarter waste solutions. Our team is passionate about sustainability, innovation, and creating technology that works for people and the planet.
          </p>
          <p className="text-gray-700 mt-2">
            By bridging the gap between unemployed youth and the circular economy, we create real impact: jobs, cleaner communities, and a healthier environment.
          </p>
        </section>

        <section className="text-center">
          <h2 className="text-2xl font-bold mb-4">Join the Movement</h2>
          <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
            Whether you’re a young collector, a recycling business, or a school ready to make an impact—EcoCycle Solutions is your platform for change.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              href="../signup"
              className="rounded-full bg-emerald-600 text-white px-6 py-3 font-medium hover:bg-emerald-700 transition-colors"
            >
              Create Your Account
            </Link>
            <Link
              href="../"
              className="rounded-full border border-emerald-600 text-emerald-600 px-6 py-3 font-medium hover:bg-emerald-50 transition-colors"
            >
              Back to Home
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 text-center text-gray-600 text-sm border-t border-gray-200 mt-16">
        <p>© {new Date().getFullYear()} EcoCycle Solutions. For a greener, fairer economy.</p>
      </footer>
    </div>
  );
}