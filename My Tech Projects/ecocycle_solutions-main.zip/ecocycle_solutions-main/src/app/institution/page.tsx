// src/app/institution/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function InstitutionDashboard() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Mock data — will come from Supabase later
  const impact = {
    totalRecycled: '2.4 Tons',
    co2Saved: '3.1 Tons',
    youthEngaged: 18,
    schoolsInNetwork: 5,
  };

  const challenges = [
    { id: 1, name: 'Plastic-Free April', status: 'Active', participants: 12, goal: '500 kg', progress: 320 },
    { id: 2, name: 'Paper Drive Challenge', status: 'Completed', participants: 24, goal: '800 kg', progress: 920 },
  ];

  const recentActivity = [
    { id: 1, event: 'Youth collector Sipho D. dropped off 12 kg of plastic', time: '2 hours ago' },
    { id: 2, event: 'Challenge “Plastic-Free April” updated: 320/500 kg', time: '1 day ago' },
    { id: 3, event: 'New agent “GreenCycle Co.” joined your network', time: '3 days ago' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="/" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="/about" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="/login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">EcoCycle Institution Hub</h1>

          <div>
            <span className="text-sm font-medium text-gray-700">Soweto High School</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome & Impact Summary */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Welcome, Soweto High School!</h2>
          <p className="text-gray-600">You’re making a real difference in your community.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Total Recycled</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impact.totalRecycled}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">CO₂ Saved</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impact.co2Saved}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Youth Engaged</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impact.youthEngaged}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Schools in Network</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impact.schoolsInNetwork}</p>
          </div>
        </div>

        {/* Two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Active Challenges */}
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-900"> Active Challenges</h3>
              <Link
            href="../institution/challenges/create"
            className="text-emerald-600 text-sm font-medium hover:underline">
             + Create New Challenge
          </Link>
            </div>
            <div className="space-y-4">
              {challenges.map((challenge) => (
                <div key={challenge.id} className="border rounded-lg p-4">
                  <div className="flex justify-between">
                    <h4 className="font-medium">{challenge.name}</h4>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      challenge.status === 'Active' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {challenge.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    {challenge.participants} participants
                  </p>
                  <div className="mt-2">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="w-full bg-gray-200 rounded-full h-2">
  <div
    className="bg-emerald-600 h-2 rounded-full"
    style={{ width: `${(challenge.progress / parseInt(challenge.goal)) * 100}%` }}
  />
</div>

                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {challenge.progress} kg / {challenge.goal} kg
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Impact & Activity */}
          <div className="space-y-8">
            {/* Impact Snapshot */}
            <div className="bg-emerald-50 p-6 rounded-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-3">Your Impact</h3>
              <p className="text-gray-700 mb-3">
                Your school’s recycling efforts have:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Diverted <strong>2.4 tons</strong> from landfills</li>
                <li>Reduced carbon emissions equivalent to <strong>driving 12,000 km</strong></li>
                <li>Created income opportunities for <strong>18 youth</strong></li>
              </ul>
              <Link
                href="/reports"
                className="mt-4 inline-block text-emerald-600 font-medium hover:underline"
              >
                View Full Impact Report →
              </Link>
            </div>

            {/* Recent Activity */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-xl font-bold text-gray-900 mb-3"> Recent Activity</h3>
              <ul className="space-y-3">
                {recentActivity.map((item) => (
                  <li key={item.id} className="text-sm text-gray-600">
                    <span className="font-medium">{item.event}</span> • {item.time}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 flex flex-wrap gap-4">
          <Link
            href="../institution/manage-partners"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
             Manage Partners (Youth & Agents)
          </Link>
          <Link
            href="../institution/materials/schedule/"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
             Schedule Bulk Pickup
          </Link>
        </div>
      </main>
    </div>
  );
}