// src/app/agent/manage-partners/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ManagePartnersPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const router = useRouter();

  // Mock partner data
  const partners = [
    {
      id: 'p1',
      name: 'Soweto High School',
      type: 'School',
      location: 'Soweto',
      materials: 'Plastic, Paper, Cardboard',
      status: 'Active',
      startDate: '2024-03-15',
      lastPickup: '2024-06-10',
      contact: 'principal@sowetohigh.co.za',
    },
    {
      id: 'p2',
      name: 'Green Futures Youth Collective',
      type: 'Youth Group',
      location: 'Alexandra',
      materials: 'Plastic, Aluminum',
      status: 'Active',
      startDate: '2024-01-20',
      lastPickup: '2024-06-12',
      contact: 'sipho@greenfutures.org',
    },
    {
      id: 'p3',
      name: 'City Mall Management',
      type: 'Business',
      location: 'Johannesburg CBD',
      materials: 'Cardboard, Plastic',
      status: 'Pending',
      startDate: null,
      lastPickup: null,
      contact: 'facilities@citymall.co.za',
    },
    {
      id: 'p4',
      name: 'Khayelitsha Community Center',
      type: 'Institution',
      materials: 'All Recyclables',
      location: 'Khayelitsha',
      status: 'Completed',
      startDate: '2023-11-01',
      lastPickup: '2024-04-30',
      contact: 'admin@kcc.org.za',
    },
  ];

  const handleSchedulePickup = (partnerName: string) => {
    alert(`Scheduling pickup with ${partnerName}`);
    // In real app: navigate to /agent/schedule-pickup with pre-filled partner
  };

  const handleEndPartnership = (partnerName: string) => {
    if (confirm(`Are you sure you want to end the partnership with ${partnerName}?`)) {
      alert(`Partnership with ${partnerName} ended.`);
      // In real app: call Supabase to update status
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="../" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="../about" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="../login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">Manage Partners</h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Your Partnerships</h2>
          <p className="text-gray-600">
            Manage your active and pending collaborations with schools, businesses, and youth groups.
          </p>
        </div>

        {partners.length === 0 ? (
          <div className="bg-white p-8 rounded-lg shadow text-center">
            <p className="text-gray-600">You don’t have any partnerships yet.</p>
            <Link
              href="/agent/partner-school"
              className="mt-4 inline-block bg-emerald-600 text-white px-4 py-2 rounded-md font-medium hover:bg-emerald-700"
            >
              + Partner with a School
            </Link>
          </div>
        ) : (
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <ul className="divide-y divide-gray-200">
              {partners.map((partner) => (
                <li key={partner.id} className="p-6">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <h3 className="text-lg font-medium text-gray-900">{partner.name}</h3>
                        <span
                          className={`ml-3 px-2 py-1 text-xs rounded-full ${
                            partner.status === 'Active'
                              ? 'bg-emerald-100 text-emerald-800'
                              : partner.status === 'Pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {partner.status}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        {partner.type} • {partner.location}
                      </p>
                      <p className="text-sm text-gray-600 mt-2">
                        <strong>Materials:</strong> {partner.materials}
                      </p>
                      <p className="text-sm text-gray-500 mt-2">
                        Contact: {partner.contact}
                      </p>
                      {partner.startDate && (
                        <p className="text-xs text-gray-500 mt-2">
                          Partnership since: {partner.startDate} • Last pickup: {partner.lastPickup || 'N/A'}
                        </p>
                      )}
                    </div>

                    <div className="mt-4 md:mt-0 md:ml-6 flex flex-wrap gap-2">
                      <button
                        onClick={() => handleSchedulePickup(partner.name)}
                        className="px-3 py-1.5 text-sm bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
                      >
                        Schedule Pickup
                      </button>
                      <button className="px-3 py-1.5 text-sm border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50">
                        Message
                      </button>
                      {partner.status === 'Active' && (
                        <button
                          onClick={() => handleEndPartnership(partner.name)}
                          className="px-3 py-1.5 text-sm text-red-600 hover:text-red-800"
                        >
                          End
                        </button>
                      )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Quick Actions */}
        <div className="mt-8 flex flex-wrap gap-4">
          <Link
            href="../agent/partner-school"
            className="bg-emerald-600 text-white px-4 py-2 rounded-md font-medium hover:bg-emerald-700"
          >
            + Add New Partner
          </Link>
          <Link
            href="../agent"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
            ← Back to Dashboard
          </Link>
        </div>
      </main>
    </div>
  );
}