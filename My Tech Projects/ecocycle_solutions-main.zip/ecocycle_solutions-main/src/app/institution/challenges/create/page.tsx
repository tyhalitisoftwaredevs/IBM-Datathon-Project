// src/app/institution/challenges/create/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function CreateChallengePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    startDate: '',
    endDate: '',
    material: '',
    goalKg: '',
    participantType: 'students', // students, staff, or public
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const router = useRouter();

  const materials = [
    'Plastic (PET)',
    'Cardboard',
    'Paper',
    'Aluminum Cans',
    'Glass',
    'All Recyclables',
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.startDate || !formData.endDate || !formData.material || !formData.goalKg) {
      alert('Please fill in all required fields.');
      return;
    }

    if (new Date(formData.startDate) >= new Date(formData.endDate)) {
      alert('End date must be after start date.');
      return;
    }

    setIsSubmitting(true);

    // 🧪 Mock API call (replace with Supabase later)
    setTimeout(() => {
      console.log('Challenge created:', formData);
      setSubmitSuccess(true);
      setIsSubmitting(false);

      setTimeout(() => {
        router.push('/institution');
      }, 2000);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="/" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="/about" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="/login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">Create New Challenge</h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Create a Recycling Challenge</h2>
          <p className="text-gray-600 mb-6">
            Engage your community with a fun, goal-driven recycling competition.
          </p>

          {submitSuccess ? (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-md mb-6">
              <p className="font-medium"> Challenge created successfully!</p>
              <p>Participants will be notified shortly.</p>
            </div>
          ) : null}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Challenge Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Challenge Name *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="e.g. Plastic-Free April"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={3}
                placeholder="e.g. Let’s collect 500kg of plastic this month and win prizes!"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">
                  Start Date *
                </label>
                <input
                  type="date"
                  id="startDate"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                />
              </div>
              <div>
                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">
                  End Date *
                </label>
                <input
                  type="date"
                  id="endDate"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                />
              </div>
            </div>

            {/* Material */}
            <div>
              <label htmlFor="material" className="block text-sm font-medium text-gray-700">
                Target Material *
              </label>
              <select
                id="material"
                name="material"
                value={formData.material}
                onChange={handleChange}
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm rounded-md"
              >
                <option value="">Select material</option>
                {materials.map((mat) => (
                  <option key={mat} value={mat}>
                    {mat}
                  </option>
                ))}
              </select>
            </div>

            {/* Goal */}
            <div>
              <label htmlFor="goalKg" className="block text-sm font-medium text-gray-700">
                Collection Goal (kg) *
              </label>
              <input
                type="number"
                id="goalKg"
                name="goalKg"
                value={formData.goalKg}
                onChange={handleChange}
                required
                min="1"
                placeholder="e.g. 500"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Participant Type */}
            <div>
              <label htmlFor="participantType" className="block text-sm font-medium text-gray-700">
                Who Can Participate? *
              </label>
              <select
                id="participantType"
                name="participantType"
                value={formData.participantType}
                onChange={handleChange}
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm rounded-md"
              >
                <option value="students">Students Only</option>
                <option value="staff">Staff Only</option>
                <option value="all">Students & Staff</option>
                <option value="public">Open to Public (Youth Collectors)</option>
              </select>
            </div>

            {/* Buttons */}
            <div className="flex flex-wrap justify-center gap-4 pt-6">
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-emerald-600 text-white font-medium rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:opacity-75"
              >
                {isSubmitting ? 'Creating...' : 'Create Challenge'}
              </button>
              <Link
                href="/institution"
                className="px-6 py-2.5 bg-emerald-700 text-white font-medium rounded-md hover:bg-emerald-800 transition-colors"
              >
                Cancel
              </Link>
            </div>
          </form>
        </div>

        {/* Info Box */}
        <div className="mt-6 bg-blue-50 p-4 rounded-lg text-sm text-blue-800">
           <strong>Pro Tip:</strong> Challenges with clear goals, short durations (2–4 weeks), and public participation tend to see the highest engagement and impact.
        </div>
      </main>
    </div>
  );
}