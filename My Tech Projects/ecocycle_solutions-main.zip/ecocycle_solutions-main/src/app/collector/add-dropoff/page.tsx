// src/app/collector/add-dropoff/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AddDropoffPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    type: 'community_bin',
    materials: '',
    contact: '',
    notes: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const router = useRouter();

  const dropoffTypes = [
    { value: 'community_bin', label: 'Community Bin' },
    { value: 'recycling_center', label: 'Recycling Center' },
    { value: 'agent_pickup', label: 'Agent Pickup Point' },
    { value: 'school_hub', label: 'School Collection Hub' },
  ];

  const materialOptions = [
    'Plastic (PET)',
    'Plastic (HDPE)',
    'Cardboard',
    'Paper',
    'Aluminum Cans',
    'Glass',
    'Metal',
    'E-Waste',
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.location || !formData.materials) {
      alert('Please fill in all required fields.');
      return;
    }

    setIsSubmitting(true);

    // 🧪 Mock submission (replace with Supabase later)
    setTimeout(() => {
      console.log('New drop-off submitted:', formData);
      setSubmitSuccess(true);
      setIsSubmitting(false);

      // Redirect after 2 seconds
      setTimeout(() => {
        router.push('/collector');
      }, 2000);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="/" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="/about" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="/login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">Add New Drop-off</h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Add a New Drop-off Location</h2>
          <p className="text-gray-600 mb-6">
            Help expand the recycling network in your community by adding new bins, centers, or pickup points.
          </p>

          {submitSuccess ? (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-md mb-6">
              <p className="font-medium">Drop-off location submitted!</p>
              <p>Our team will verify and add it to the map soon.</p>
            </div>
          ) : null}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Location Name *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="e.g. Soweto Community Bin"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Location (Address or Description) */}
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700">
                Address or Description *
              </label>
              <input
                type="text"
                id="location"
                name="location"
                value={formData.location}
                onChange={handleChange}
                required
                placeholder="e.g. Corner of Main & 5th St, Soweto"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Type */}
            <div>
              <label htmlFor="type" className="block text-sm font-medium text-gray-700">
                Type *
              </label>
              <select
                id="type"
                name="type"
                value={formData.type}
                onChange={handleChange}
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm rounded-md"
              >
                {dropoffTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Materials Accepted */}
            <div>
              <label htmlFor="materials" className="block text-sm font-medium text-gray-700">
                Materials Accepted *
              </label>
              <select
                id="materials"
                name="materials"
                value={formData.materials}
                onChange={handleChange}
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm rounded-md"
              >
                <option value="">Select primary material</option>
                {materialOptions.map((mat) => (
                  <option key={mat} value={mat}>
                    {mat}
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-1">
                You can specify more details in the notes below.
              </p>
            </div>

            {/* Contact (Optional) */}
            <div>
              <label htmlFor="contact" className="block text-sm font-medium text-gray-700">
                Contact Info (Optional)
              </label>
              <input
                type="text"
                id="contact"
                name="contact"
                value={formData.contact}
                onChange={handleChange}
                placeholder="e.g. Name, phone, or email"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Notes */}
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Additional Notes
              </label>
              <textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={3}
                placeholder="e.g. Open daily 8am–5pm, gate code: 1234, accepts clean plastic only"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Buttons */}
            <div className="flex flex-wrap gap-3 pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`flex-1 sm:flex-none px-4 py-2 bg-emerald-600 text-white font-medium rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 ${
                  isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
                }`}
              >
                {isSubmitting ? 'Submitting...' : 'Add Drop-off'}
              </button>
              <Link
                href="../collector"
                className="px-6 py-2.5 bg-emerald-700 text-white font-medium rounded-md hover:bg-emerald-800 transition-colors inline-block"
                >
                Cancel
              </Link>
            </div>
          </form>
        </div>

        {/* Info Box */}
        <div className="mt-6 bg-blue-50 p-4 rounded-lg text-sm text-blue-800">
          <strong>Why add drop-offs?</strong> More locations mean easier access for collectors, cleaner communities, and more income opportunities for youth like you!
        </div>
      </main>
    </div>
  );
}