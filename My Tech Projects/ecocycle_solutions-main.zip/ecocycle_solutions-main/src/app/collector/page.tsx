// src/app/collector/page.tsx
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function CollectorDashboard() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [earnings, setEarnings] = useState({ thisWeek: 'R0.00', total: 'R0.00', recycledKg: 0 });
  const [trendingMaterials, setTrendingMaterials] = useState<any[]>([]);
  const [nearbyAgents, setNearbyAgents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      // ✅ Get current session
      const { data: sessionData } = await supabase.auth.getSession();
      const session = sessionData?.session;

      if (!session) {
        window.location.href = '/login';
        return;
      }

      const userId = session.user.id;

      // ✅ Fetch user profile
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', userId)
        .single();

      if (profileError) console.error(profileError);
      if (profile) setUser(profile);

      // ✅ Fetch recycled logs
      const { data: logs, error: logsError } = await supabase
        .from('recycled_logs')
        .select('weight_kg, earnings, created_at')
        .eq('collector_id', userId);

      if (logsError) console.error(logsError);
      if (logs && logs.length > 0) {
        const totalEarnings = logs.reduce((sum: number, log: any) => sum + (log.earnings || 0), 0);
        const totalKg = logs.reduce((sum: number, log: any) => sum + (log.weight_kg || 0), 0);
        const thisWeekEarnings = logs
          .filter((log: any) => {
            const logDate = new Date(log.created_at);
            const weekAgo = new Date();
            weekAgo.setDate(weekAgo.getDate() - 7);
            return logDate >= weekAgo;
          })
          .reduce((sum: number, log: any) => sum + (log.earnings || 0), 0);

        setEarnings({
          thisWeek: `R${thisWeekEarnings.toFixed(2)}`,
          total: `R${totalEarnings.toFixed(2)}`,
          recycledKg: Math.round(totalKg),
        });
      }

      // ✅ Fetch trending materials
      const { data: materials, error: matError } = await supabase
        .from('materials')
        .select('name')
        .limit(3);

      if (matError) console.error(matError);

      const mockTrends = [
        { name: materials?.[0]?.name || 'Plastic (PET)', price: 'R2.50/kg', trend: '↑ 12%', hotspot: 'Soweto' },
        { name: materials?.[1]?.name || 'Cardboard', price: 'R1.80/kg', trend: '↑ 8%', hotspot: 'Alexandra' },
        { name: materials?.[2]?.name || 'Aluminum Cans', price: 'R8.00/kg', trend: '→ Stable', hotspot: 'City Center' },
      ];
      setTrendingMaterials(mockTrends);

      // ✅ Fetch nearby agents
      const { data: agents, error: agentError } = await supabase
        .from('profiles')
        .select('full_name, organization_name, location')
        .eq('user_type', 'agent')
        .limit(3);

      if (agentError) console.error(agentError);

      const formattedAgents = (agents || []).map((agent: any, idx: number) => ({
        id: idx + 1,
        name: agent.organization_name || agent.full_name || 'Recycling Agent',
        location: agent.location || 'Nearby',
        materials: 'Plastic, Paper, Metal',
        rating: (4.5 + Math.random() * 0.5).toFixed(1),
      }));

      setNearbyAgents(formattedAgents);
      setLoading(false);
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading your dashboard...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>

            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link
                  href="/"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link
                  href="/about"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  About Us
                </Link>
                {/* ✅ Fixed: removed invalid closing </Link> tag */}
                <button
                  onClick={async () => {
                    await supabase.auth.signOut();
                    window.location.href = '/login';
                  }}
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-emerald-50"
                >
                  Logout
                </button>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">EcoCycle Collector Hub</h1>
          <div>
            <span className="text-sm font-medium text-gray-700">{user?.full_name || 'Collector'}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome & Earnings Summary */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">
            Hi {user?.full_name?.split(' ')[0] || 'there'}, ready to collect?
          </h2>
          <p className="text-gray-600">
            You’ve recycled <span className="font-medium">{earnings.recycledKg} kg</span> so far!
          </p>
        </div>

        {/* Earnings Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">This Week’s Earnings</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{earnings.thisWeek}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Total Earned</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{earnings.total}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Kilograms Recycled</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{earnings.recycledKg} kg</p>
          </div>
        </div>

        {/* Trending Materials */}
        <div className="bg-white p-6 rounded-lg shadow mb-8">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-900">Trending Materials</h3>
            <Link href="/learn" className="text-emerald-600 text-sm font-medium hover:underline">
              Recycling Tips →
            </Link>
          </div>
          <div className="space-y-4">
            {trendingMaterials.map((mat, idx) => (
              <div key={idx} className="flex justify-between items-center border-b pb-3">
                <div>
                  <p className="font-medium">{mat.name}</p>
                  <p className="text-sm text-gray-600">{mat.price} • {mat.hotspot}</p>
                </div>
                <span className="text-sm font-medium text-emerald-600">{mat.trend}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Two-column section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Nearby Agents */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Nearby Buyers</h3>
            <div className="space-y-4">
              {nearbyAgents.map((agent) => (
                <div key={agent.id} className="border rounded-lg p-4">
                  <h4 className="font-medium">{agent.name}</h4>
                  <p className="text-sm text-gray-600 mt-1">{agent.location}</p>
                  <p className="text-sm text-gray-500">Buys: {agent.materials}</p>
                  <div className="flex items-center mt-2">
                    <span className="text-sm text-emerald-600">★ {agent.rating}</span>
                    <button className="ml-auto text-sm text-emerald-600 hover:underline">View Details</button>
                  </div>
                </div>
              ))}
            </div>
            <Link
              href="/collector/add-dropoff"
              className="mt-4 w-full py-2 border border-emerald-600 text-emerald-600 rounded-md text-sm font-medium hover:bg-emerald-50 text-center block"
            >
              + Add New Drop-off
            </Link>
          </div>

          {/* Quick Tips */}
          <div className="bg-emerald-50 p-6 rounded-lg">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Quick Recycling Tips</h3>
            <ul className="space-y-3 text-gray-700">
              <li><span className="text-emerald-600 mr-2">✓</span><strong>Plastic bottles:</strong> Remove caps, rinse, flatten.</li>
              <li><span className="text-emerald-600 mr-2">✓</span><strong>Cardboard:</strong> Flatten boxes, remove tape.</li>
              <li><span className="text-emerald-600 mr-2">✓</span><strong>Aluminum cans:</strong> Rinse, don’t crush.</li>
              <li><span className="text-emerald-600 mr-2">✓</span>E-waste? Bring to certified e-waste centers only.</li>
            </ul>
            <Link href="/learn" className="mt-4 inline-block text-emerald-600 font-medium hover:underline">
              View Full Guide →
            </Link>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-8 flex flex-wrap gap-4">
          <Link
            href="/collector/log-materials"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
            Log Recycled Materials
          </Link>
          <Link
            href="/collector/rewards"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
            View Rewards
          </Link>
        </div>
      </main>
    </div>
  );
}
