// src/app/collector/log-materials/page.tsx
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

interface Material {
  id: string;
  name: string;
}

export default function LogMaterialsPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    materialId: '',
    weightKg: '',
    dropOffLocation: '',
    notes: '',
  });
  const [photo, setPhoto] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const fetchMaterials = async () => {
      const { data, error } = await supabase
        .from('materials')
        .select('id, name');

      if (error) {
        console.error('Error fetching materials:', error);
      } else {
        setMaterials(data || []);
      }
      setLoading(false);
    };

    fetchMaterials();
  }, []);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPhoto(e.target.files[0]);
    }
  };

  const getMaterialName = (id: string) => {
    const material = materials.find((m) => m.id === id);
    return material ? material.name : '';
  };

  const getEstimatedEarnings = () => {
    const mockPrices: Record<string, number> = {
      'Plastic (PET)': 2.5,
      Cardboard: 1.8,
      'Aluminum Cans': 8.0,
      'Glass (Clear)': 0.9,
      Paper: 1.2,
      'Plastic (HDPE)': 2.2,
    };
    const materialName = getMaterialName(formData.materialId);
    const price = mockPrices[materialName] || 0;
    const weight = parseFloat(formData.weightKg) || 0;
    return price * weight;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.materialId || !formData.weightKg || !formData.dropOffLocation) {
      alert('Please fill in all required fields.');
      return;
    }

    setIsSubmitting(true);

    try {
      const {
        data: { session },
        error: sessionError,
      } = await supabase.auth.getSession();

      if (sessionError || !session) throw new Error('Not authenticated');

      let photoUrl = null;

      if (photo) {
        const fileName = `${session.user.id}/${Date.now()}_${photo.name}`;
        const { error: uploadError } = await supabase.storage
          .from('recycled-photos')
          .upload(fileName, photo);

        if (uploadError) throw uploadError;
        photoUrl = fileName;
      }

      const earnings = getEstimatedEarnings();

      const { error: logError } = await supabase.from('recycled_logs').insert({
        collector_id: session.user.id,
        material_id: formData.materialId,
        weight_kg: parseFloat(formData.weightKg),
        location: formData.dropOffLocation,
        notes: formData.notes,
        photo_url: photoUrl,
        earnings,
        status: 'pending',
      });

      if (logError) throw logError;

      setSubmitSuccess(true);
      setTimeout(() => router.push('/collector'), 2000);
    } catch (error) {
      console.error('Error logging material:', error);
      alert('Failed to log material. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading materials...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link
                  href="/"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link
                  href="/about"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  About Us
                </Link>
                <button
                  onClick={async () => {
                    await supabase.auth.signOut();
                    router.push('/login');
                  }}
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-emerald-50"
                >
                  Logout
                </button>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">Log Recycled Materials</h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Form */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Log Your Recycled Materials</h2>
          <p className="text-gray-600 mb-6">
            Track what you’ve collected and earn rewards based on current market prices.
          </p>

          {submitSuccess ? (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-md mb-6">
              <p className="font-medium">
                ✅ Success! You’ve earned <strong>R{getEstimatedEarnings().toFixed(2)}</strong>!
              </p>
              <p>Redirecting to your dashboard...</p>
            </div>
          ) : (
            <div className="mb-6 p-4 bg-emerald-50 rounded-lg">
              <p className="text-emerald-800 font-medium">
                💰 Estimated Earnings: <strong>R{getEstimatedEarnings().toFixed(2)}</strong>
              </p>
              <p className="text-sm text-emerald-700 mt-1">
                Based on current market rates for{' '}
                {getMaterialName(formData.materialId) || 'selected material'}.
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Material Type */}
            <div>
              <label htmlFor="materialId" className="block text-sm font-medium text-gray-700">
                Material Type *
              </label>
              <select
                id="materialId"
                name="materialId"
                value={formData.materialId}
                onChange={handleChange}
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm rounded-md"
              >
                <option value="">Select a material</option>
                {materials.map((mat) => (
                  <option key={mat.id} value={mat.id}>
                    {mat.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Weight */}
            <div>
              <label htmlFor="weightKg" className="block text-sm font-medium text-gray-700">
                Weight (kg) *
              </label>
              <input
                type="number"
                id="weightKg"
                name="weightKg"
                value={formData.weightKg}
                onChange={handleChange}
                required
                min="0.1"
                step="0.1"
                placeholder="e.g. 5.5"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Drop-off Location */}
            <div>
              <label htmlFor="dropOffLocation" className="block text-sm font-medium text-gray-700">
                Drop-off or Pickup Location *
              </label>
              <input
                type="text"
                id="dropOffLocation"
                name="dropOffLocation"
                value={formData.dropOffLocation}
                onChange={handleChange}
                required
                placeholder="e.g. Soweto Recycling Hub"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Notes */}
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Notes
              </label>
              <textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={2}
                placeholder="e.g. Clean plastic bottles, no caps"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Photo Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Material Photo (Optional)
              </label>
              <div className="flex items-center justify-center w-full">
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <svg
                      className="w-8 h-8 text-gray-400 mb-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
                      />
                    </svg>
                    <p className="text-xs text-gray-500">
                      {photo ? photo.name : 'Click to upload'}
                    </p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleFileChange}
                  />
                </label>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Photos help verify your submission and speed up payment.
              </p>
            </div>

            {/* Buttons */}
            <div className="flex flex-wrap gap-3 pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`flex-1 sm:flex-none px-4 py-2 bg-emerald-600 text-white font-medium rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 ${
                  isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
                }`}
              >
                {isSubmitting ? 'Logging...' : 'Log & Earn'}
              </button>
              <Link
                href="/collector"
                className="flex-1 sm:flex-none px-4 py-2 text-center border border-gray-300 text-gray-700 font-medium rounded-md hover:bg-gray-50"
              >
                Cancel
              </Link>
            </div>
          </form>
        </div>

        {/* Info Box */}
        <div className="mt-6 bg-blue-50 p-4 rounded-lg text-sm text-blue-800">
          💡 <strong>Tip:</strong> Focus on materials with the highest demand (like Plastic and Aluminum)
          to maximize your earnings!
        </div>
      </main>
    </div>
  );
}
