// src/app/collector/rewards/page.tsx
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function RewardsPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedReward, setSelectedReward] = useState<string | null>(null);
  const [isRedeeming, setIsRedeeming] = useState(false);
  const [totalPoints, setTotalPoints] = useState(0);
  const [availableRewards, setAvailableRewards] = useState<any[]>([]);
  const [recentRedemptions, setRecentRedemptions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const fetchRewardsData = async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const session = sessionData?.session;

      if (!session) {
        router.push('/login');
        return;
      }

      const userId = session.user.id;

      // Fetch total points (sum of earnings from recycled_logs)
      const { data: logs, error: logsError } = await supabase
        .from('recycled_logs')
        .select('earnings')
        .eq('collector_id', userId)
        .eq('status', 'verified');

      if (logsError) {
        console.error('Error fetching logs:', logsError);
      }

      const points = logs?.reduce(
        (sum: number, log: any) => sum + (log.earnings || 0),
        0
      ) || 0;
      setTotalPoints(Math.floor(points));

      // Fetch available rewards
      const { data: rewards, error: rewardsError } = await supabase
        .from('rewards')
        .select('*')
        .eq('is_active', true)
        .order('cost_points', { ascending: true });

      if (rewardsError) {
        console.error('Error fetching rewards:', rewardsError);
      }

      setAvailableRewards(rewards || []);

      // Fetch recent redemptions
      const { data: redemptions, error: redemptionsError } = await supabase
        .from('redemptions')
        .select('reward_id, status, created_at, rewards(name)')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(5);

      if (redemptionsError) {
        console.error('Error fetching redemptions:', redemptionsError);
      }

      const formattedRedemptions =
        redemptions?.map((r: any) => ({
          id: r.reward_id,
          reward: r.rewards?.name || 'Unknown Reward',
          date: new Date(r.created_at).toISOString().split('T')[0],
          status:
            r.status.charAt(0).toUpperCase() + r.status.slice(1),
        })) || [];

      setRecentRedemptions(formattedRedemptions);
      setLoading(false);
    };

    fetchRewardsData();
  }, [router]);

  const handleRedeem = async () => {
    if (!selectedReward) return;

    const reward = availableRewards.find((r) => r.id === selectedReward);
    if (!reward || totalPoints < reward.cost_points) {
      alert('Not enough points!');
      return;
    }

    setIsRedeeming(true);

    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;

    if (!session) {
      setIsRedeeming(false);
      router.push('/login');
      return;
    }

    const { error } = await supabase.from('redemptions').insert({
      user_id: session.user.id,
      reward_id: reward.id,
      points_used: reward.cost_points,
      status: 'pending',
    });

    if (error) {
      console.error('Redemption error:', error);
      alert('Failed to redeem reward. Please try again.');
    } else {
      alert(`✅ Redeemed: ${reward.name}!`);
      window.location.reload();
    }

    setIsRedeeming(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading your rewards...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link
                  href="/"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link
                  href="/about"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  About Us
                </Link>
                <button
                  onClick={async () => {
                    await supabase.auth.signOut();
                    router.push('/login');
                  }}
                  className="block w-full text-left px-4 py-2 text-gray-800 hover:bg-emerald-50"
                >
                  Logout
                </button>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">
            My Rewards
          </h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Points Summary */}
        <div className="bg-white p-6 rounded-lg shadow text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900">
            Your Rewards Balance
          </h2>
          <p className="text-4xl font-bold text-emerald-600 mt-2">
            {totalPoints} pts
          </p>
          <p className="text-gray-600 mt-2">1 point = R1.00 value</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Available Rewards */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Available Rewards
            </h3>
            <div className="space-y-4">
              {availableRewards.length > 0 ? (
                availableRewards.map((reward) => (
                  <div
                    key={reward.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                      selectedReward === reward.id
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedReward(reward.id)}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-medium">{reward.name}</h4>
                        <p className="text-sm text-gray-600">
                          Cost: {reward.cost_points} pts
                        </p>
                      </div>
                      {selectedReward === reward.id && (
                        <span className="text-emerald-600 font-medium">
                          ✓ Selected
                        </span>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-gray-600">No rewards available.</p>
              )}
            </div>

            <button
              onClick={handleRedeem}
              disabled={
                !selectedReward ||
                isRedeeming ||
                totalPoints <
                  (availableRewards.find(
                    (r) => r.id === selectedReward
                  )?.cost_points || 0)
              }
              className={`mt-6 w-full py-2 px-4 rounded-md font-medium ${
                selectedReward &&
                totalPoints >=
                  (availableRewards.find(
                    (r) => r.id === selectedReward
                  )?.cost_points || 0)
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
            >
              {isRedeeming ? 'Processing...' : 'Redeem Reward'}
            </button>
          </div>

          {/* Recent Activity */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Recent Redemptions
            </h3>
            {recentRedemptions.length > 0 ? (
              <ul className="space-y-4">
                {recentRedemptions.map((item, idx) => (
                  <li
                    key={idx}
                    className="border-b pb-3 last:border-0 last:pb-0"
                  >
                    <div className="flex justify-between">
                      <span className="font-medium">{item.reward}</span>
                      <span className="text-sm text-gray-600">
                        {item.date}
                      </span>
                    </div>
                    <span
                      className={`text-xs inline-block mt-1 px-2 py-1 rounded-full ${
                        item.status === 'Completed'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {item.status}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-600">No redemptions yet.</p>
            )}

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-800">How It Works</h4>
              <ul className="text-sm text-blue-700 mt-2 space-y-1">
                <li>• Earn 1 point for every R1.00 of recycled material</li>
                <li>• Redeem points for cash, vouchers, or gear</li>
                <li>• Payouts processed weekly via mobile money</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Back Button */}
        <div className="mt-8 text-center">
          <Link
            href="/collector"
            className="text-emerald-600 font-medium hover:underline"
          >
            ← Back to Dashboard
          </Link>
        </div>
      </main>
    </div>
  );
}
