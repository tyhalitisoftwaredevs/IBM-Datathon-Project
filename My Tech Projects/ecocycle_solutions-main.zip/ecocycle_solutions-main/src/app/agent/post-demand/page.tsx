'use client';

import React, { useState, ChangeEvent, FormEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function PostDemandPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    material: '',
    pricePerKg: '',
    quantityNeeded: '',
    location: '',
    notes: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const router = useRouter();

  const materials = [
    'Plastic (PET)',
    'Plastic (HDPE)',
    'Cardboard',
    'Paper',
    'Aluminum Cans',
    'Glass (Clear)',
    'Glass (Colored)',
    'E-Waste',
    'Metal (Ferrous)',
    'Metal (Non-Ferrous)',
  ];

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    // 🧪 Mock API call (replace with Supabase insert later)
    setTimeout(() => {
      console.log('Demand posted:', formData);
      setSubmitSuccess(true);
      setIsSubmitting(false);

      // Redirect after 2 seconds
      setTimeout(() => {
        router.push('../agent');
      }, 2000);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link
                  href="../"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link
                  href="../about"
                  className="block px-4 py-2 text-gray-800 hover:bg-emerald-50"
                  onClick={() => setIsMenuOpen(false)}
                >
                  About Us
                </Link>
                <Link href="../login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">Post New Demand</h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Post New Demand</h2>

          {submitSuccess && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-md mb-6">
              <p className="font-medium">Demand posted successfully!</p>
              <p>Redirecting to your dashboard...</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Material Type */}
            <div>
              <label htmlFor="material" className="block text-sm font-medium text-gray-700">
                Material Type *
              </label>
              <select
                id="material"
                name="material"
                value={formData.material}
                onChange={handleChange}
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm rounded-md"
              >
                <option value="">Select a material</option>
                {materials.map((mat) => (
                  <option key={mat} value={mat}>
                    {mat}
                  </option>
                ))}
              </select>
            </div>

            {/* Price per kg */}
            <div>
              <label htmlFor="pricePerKg" className="block text-sm font-medium text-gray-700">
                Price Offered (R/kg) *
              </label>
              <input
                type="number"
                id="pricePerKg"
                name="pricePerKg"
                value={formData.pricePerKg}
                onChange={handleChange}
                required
                min="0"
                step="0.01"
                placeholder="e.g. 2.50"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Quantity Needed */}
            <div>
              <label htmlFor="quantityNeeded" className="block text-sm font-medium text-gray-700">
                Quantity Needed (kg) *
              </label>
              <input
                type="number"
                id="quantityNeeded"
                name="quantityNeeded"
                value={formData.quantityNeeded}
                onChange={handleChange}
                required
                min="1"
                placeholder="e.g. 500"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Pickup Location */}
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700">
                Preferred Pickup Location *
              </label>
              <input
                type="text"
                id="location"
                name="location"
                value={formData.location}
                onChange={handleChange}
                required
                placeholder="e.g. Soweto Recycling Hub, 123 Main St"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Notes */}
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Additional Notes (optional)
              </label>
              <textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={3}
                placeholder="Add any special instructions or timing preferences..."
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2 px-4 bg-emerald-600 text-white font-semibold rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:opacity-50"
            >
              {isSubmitting ? 'Posting...' : 'Post Demand'}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
