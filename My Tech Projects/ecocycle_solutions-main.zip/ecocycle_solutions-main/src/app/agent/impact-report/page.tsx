// src/app/agent/impact-report/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function ImpactReportPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Mock data — replace with Supabase queries later
  const impactData = {
    totalMaterialsKg: 4820,
    co2SavedKg: 3615,
    youthEngaged: 18,
    totalValue: 'R12,050',
    topMaterial: 'Plastic (PET)',
    activeMonths: 6,
  };

  const monthlyTrends = [
    { month: 'Jan', kg: 620 },
    { month: 'Feb', kg: 710 },
    { month: 'Mar', kg: 840 },
    { month: 'Apr', kg: 950 },
    { month: 'May', kg: 820 },
    { month: 'Jun', kg: 880 },
  ];

  const materialBreakdown = [
    { name: 'Plastic (PET)', percent: 45, color: 'bg-emerald-500' },
    { name: 'Cardboard', percent: 25, color: 'bg-amber-500' },
    { name: 'Aluminum', percent: 15, color: 'bg-gray-400' },
    { name: 'Glass', percent: 10, color: 'bg-blue-400' },
    { name: 'Other', percent: 5, color: 'bg-purple-400' },
  ];

  const hotspots = ['Soweto', 'Alexandra', 'Orlando East', 'Diepsloot'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="../" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="../about" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="../login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">Impact Report</h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Your Impact Report</h2>
          <p className="text-gray-600">June 2024 • Agent Co. Recycling</p>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Total Materials Collected</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impactData.totalMaterialsKg.toLocaleString()} kg</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">CO₂ Emissions Saved</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impactData.co2SavedKg.toLocaleString()} kg</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Youth Engaged</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impactData.youthEngaged}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow text-center">
            <p className="text-sm text-gray-600">Total Value Generated</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{impactData.totalValue}</p>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
          {/* Monthly Trend */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Monthly Collection Trend</h3>
            <div className="space-y-4">
              {monthlyTrends.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{item.month}</span>
                    <span className="font-medium">{item.kg} kg</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-emerald-600 h-2 rounded-full"
                      style={{ width: `${(item.kg / 1000) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Material Breakdown */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Material Breakdown</h3>
            <div className="space-y-3">
              {materialBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{item.name}</span>
                    <span className="font-medium">{item.percent}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`${item.color} h-2 rounded-full`}
                      style={{ width: `${item.percent}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Insights */}
        <div className="bg-emerald-50 p-6 rounded-lg mb-10">
          <h3 className="text-xl font-bold text-gray-900 mb-3">Key Insights</h3>
          <ul className="list-disc pl-5 space-y-2 text-gray-700">
            <li>
              <strong>{impactData.topMaterial}</strong> is your most collected material (45% of total volume).
            </li>
            <li>
              You’ve prevented the equivalent of <strong>driving 14,500 km</strong> in CO₂ emissions.
            </li>
            <li>
              High-yield collection zones: <strong>{hotspots.join(', ')}</strong>.
            </li>
            <li>
              You’ve been active for <strong>{impactData.activeMonths} months</strong> — keep it up!
            </li>
          </ul>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-4">
          <button
            onClick={() => window.print()}
            className="bg-emerald-600 text-white px-4 py-2 rounded-md font-medium hover:bg-emerald-700"
          >
            Print Report
          </button>
          <Link
            href="../agent"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
            ← Back to Dashboard
          </Link>
        </div>
      </main>
    </div>
  );
}