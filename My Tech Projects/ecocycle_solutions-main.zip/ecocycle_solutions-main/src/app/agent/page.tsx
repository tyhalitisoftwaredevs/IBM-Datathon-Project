// src/app/agent/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function AgentDashboard() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [demandItems, setDemandItems] = useState([
    { id: 1, material: 'Plastic (PET)', price: 'R2.50/kg', active: true },
    { id: 2, material: 'Cardboard', price: 'R1.80/kg', active: true },
    { id: 3, material: 'Aluminum Cans', price: 'R8.00/kg', active: false },
  ]);

  const collectors = [
    { id: 1, name: 'Thabo M.', location: 'Soweto', materials: 'Plastic, Glass', rating: 4.8 },
    { id: 2, name: 'Naledi K.', location: 'Alexandra', materials: 'Paper, Cardboard', rating: 4.6 },
    { id: 3, name: 'Sipho D.', location: 'Khayelitsha', materials: 'Plastic, Metal', rating: 4.9 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="../" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="../about" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="../login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">EcoCycle Agent Dashboard</h1>

          <div>
            <span className="text-sm font-medium text-gray-700">Agent Co.</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome & Stats */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Welcome back, Agent!</h2>
          <p className="text-gray-600">Manage your recycling operations and connect with collectors.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-900">Active Collectors</h3>
            <p className="text-3xl font-bold text-emerald-600 mt-2">24</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-900">This Week’s Volume</h3>
            <p className="text-3xl font-bold text-emerald-600 mt-2">1.2 Tons</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-900">Pending Pickups</h3>
            <p className="text-3xl font-bold text-emerald-600 mt-2">5</p>
          </div>
        </div>

      {/* Demand Board */}
<div className="bg-white p-6 rounded-lg shadow mb-8">
  <div className="flex justify-between items-center mb-4">
    <h3 className="text-xl font-bold text-gray-900">Current Demand</h3>
    <Link
      href="../agent/post-demand"
      className="bg-emerald-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-emerald-700"
    >
      + Post New Demand
    </Link>
  </div>
          <div className="space-y-4">
            {demandItems.map((item) => (
              <div key={item.id} className="flex justify-between items-center border-b pb-3">
                <div>
                  <p className="font-medium">{item.material}</p>
                  <p className="text-sm text-gray-600">{item.price}</p>
                </div>
                <div className="flex space-x-2">
                  <button className="text-sm text-emerald-600 hover:underline">
                    {item.active ? 'Deactivate' : 'Activate'}
                  </button>
                  <button className="text-sm text-gray-500 hover:underline">Edit</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Two-column layout: Collectors + Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Nearby Collectors */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Nearby Collectors</h3>
            <div className="space-y-4">
              {collectors.map((collector) => (
                <div key={collector.id} className="border rounded-lg p-4">
                  <div className="flex justify-between">
                    <h4 className="font-medium">{collector.name}</h4>
                    <span className="text-sm text-emerald-600">★ {collector.rating}</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{collector.location}</p>
                  <p className="text-sm text-gray-500">Materials: {collector.materials}</p>
                  <button className="mt-2 text-sm text-emerald-600 hover:underline">Message</button>
                </div>
              ))}
            </div>
          </div>

          {/* Analytics */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Supply Trends</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium">Plastic (PET)</p>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                  <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium">Cardboard</p>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                  <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium">Glass</p>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                  <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '40%' }}></div>
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-4">
                High supply in <span className="font-medium">Soweto, Alexandra</span>
              </p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 flex flex-wrap gap-4">
          <Link
            href="../agent/schedule-pickup"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
            Schedule Pickup
          </Link>
          <Link
            href="../agent/impact-report"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
            View Impact Report
          </Link>
          <Link
            href="../agent/partner-school"
            className="bg-white border border-emerald-600 text-emerald-600 px-4 py-2 rounded-md font-medium hover:bg-emerald-50"
          >
            Partner with School
          </Link>
        </div>
      </main>
    </div>
  );
}