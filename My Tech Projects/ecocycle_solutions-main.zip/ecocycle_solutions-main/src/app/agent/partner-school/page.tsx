// src/app/agent/partner-school/page.tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function PartnerWithSchoolPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const router = useRouter();

  // Mock list of schools near the agent
  const schools = [
    { id: 'sch-001', name: 'Soweto High School', location: 'Soweto', students: 1200, hasRecycling: true },
    { id: 'sch-002', name: 'Alexandra Secondary', location: 'Alexandra', students: 950, hasRecycling: false },
    { id: 'sch-003', name: 'Khayelitsha Academy', location: 'Khayelitsha', students: 1400, hasRecycling: true },
    { id: 'sch-004', name: 'Diepsloot Community School', location: 'Diepsloot', students: 800, hasRecycling: false },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool || !message.trim()) {
      alert('Please select a school and write a message.');
      return;
    }

    setIsSubmitting(true);

    // Mock API call (replace with Supabase later)
    setTimeout(() => {
      console.log('Partnership request sent to:', selectedSchool, 'Message:', message);
      setSubmitSuccess(true);
      setIsSubmitting(false);

      // Redirect after 2 seconds
      setTimeout(() => {
        router.push('/agent');
      }, 2000);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <header className="bg-white border-b border-gray-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-emerald-600 hover:text-emerald-800 focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                <Link href="../" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  Home
                </Link>
                <Link href="../about" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50" onClick={() => setIsMenuOpen(false)}>
                  About Us
                </Link>
                <Link href="../login" className="block px-4 py-2 text-gray-800 hover:bg-emerald-50">
                  Logout
                </Link>
              </div>
            )}
          </div>

          <h1 className="text-xl font-bold text-gray-900 hidden md:block">Partner with School</h1>
          <div className="w-6 md:w-auto"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Partner with a School</h2>
          <p className="text-gray-600 mb-6">
            Build long-term recycling partnerships with schools in your area.
          </p>

          {submitSuccess ? (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-md mb-6">
              <p className="font-medium">Partnership request sent!</p>
              <p>We’ll notify you once the school responds.</p>
            </div>
          ) : null}

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* School Selection */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Available Schools</h3>
              <div className="space-y-4">
                {schools.map((school) => (
                  <div
                    key={school.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                      selectedSchool === school.id
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedSchool(school.id)}
                  >
                    <div className="flex justify-between">
                      <h4 className="font-medium">{school.name}</h4>
                      {school.hasRecycling && (
                        <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-1 rounded-full">
                          Active Recycler
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{school.location} • {school.students} students</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Message */}
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                Your Proposal *
              </label>
              <textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={5}
                placeholder="Introduce your company and propose a partnership. Example: We offer weekly pickups, impact reports, and recycling workshops for students."
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                required
              />
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-3 pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`flex-1 sm:flex-none px-4 py-2 bg-emerald-600 text-white font-medium rounded-md hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 ${
                  isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
                }`}
              >
                {isSubmitting ? 'Sending...' : 'Send Partnership Request'}
              </button>
              <Link
                href="../agent"
                className="flex-1 sm:flex-none px-4 py-2 text-center border border-gray-300 text-gray-700 font-medium rounded-md hover:bg-gray-50"
              >
                Cancel
              </Link>
            </div>
          </form>
        </div>

        {/* Info Box */}
        <div className="mt-8 bg-blue-50 p-4 rounded-lg text-sm text-blue-800">
        <strong>Why partner with schools?</strong> Schools generate consistent recyclable waste (paper, plastic, cans) and offer opportunities for youth engagement, education, and community impact.
        </div>
      </main>
    </div>
  );
}